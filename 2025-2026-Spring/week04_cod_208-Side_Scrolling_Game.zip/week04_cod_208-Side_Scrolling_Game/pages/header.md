# Creative Coding

2D Game Design

<div class="pt-12">
  <span @click="$slidev.nav.next" class="px-2 p-1 rounded cursor-pointer" hover="bg-white bg-opacity-10">
    COD 208 - Week 04 Class <carbon:arrow-right class="inline" />
  </span>
</div>

<a href="https://github.com/alptugan/Slidev_Presentations" target="_blank" alt="GitHub"
  class="abs-br m-6 text-xl slidev-icon-btn opacity-50 !border-none !hover:text-white"><carbon-logo-github /></a>