<!-- global-bottom.vue -->
<script setup lang="ts">
import { useNav } from "@slidev/client";
import seedrandom from "seedrandom";
/**
 * A new glow effect system powered by blured polygons
 *
 * Credits to @pi0 @Atinux
 *
 * Properties:
 * - glow: 'left' | 'right' | 'top' | 'bottom' | 'full' -  Distribution of the polygons points
 * - glowOpacity: number - Opacity of the polygons (4)
 * - glowHue: number - Hue shift for the polygons (default: 0)
 * - glowSeed: string | false - Seed for the stable random distribution (default: 'default')
 */
import { computed, ref, watch } from "vue";

const { currentSlideRoute } = useNav();

export type Range = [number, number];

export type Distribution =
    | "full"
    | "top"
    | "bottom"
    | "left"
    | "right"
    | "top-left"
    | "top-right"
    | "bottom-left"
    | "bottom-right"
    | "center";

const formatter = computed(() => (currentSlideRoute.value.meta?.slide as any)?.frontmatter || {});
const distribution = computed(() => (formatter.value.glow || "full") as Distribution);
const opacity = computed<number>(() => +(formatter.value.glowOpacity || 0.4));
const hue = computed<number>(() => +(formatter.value.glowHue || 0));
const seed = computed<string>(() =>
    formatter.value.glowSeed === "false" || formatter.value.glowSeed === false
        ? Date.now().toString()
        : formatter.value.glowSeed || "default",
);
const overflow = 0.3;
const disturb = 0.3;
const disturbChance = 0.3;

function distributionToLimits(distribution: Distribution) {
    const min = -0.2;
    const max = 4.2;
    let x: Range = [min, max];
    let y: Range = [min, max];

    function intersection(a: Range, b: Range): Range {
        return [Math.max(a[0], b[0]), Math.min(a[1], b[1])];
    }

    const limits = distribution.split("-");

    for (const limit of limits) {
        switch (limit) {
            case "top":
                y = intersection(y, [min, 0.6]);
                break;
            case "bottom":
                y = intersection(y, [0.4, max]);
                break;
            case "left":
                x = intersection(x, [min, 0.6]);
                break;
            case "right":
                x = intersection(x, [0.4, max]);
                break;
            case "xcenter":
                x = intersection(x, [0.25, 0.75]);
                break;
            case "ycenter":
                y = intersection(y, [0.25, 0.75]);
                break;
            case "center":
                x = intersection(x, [0.25, 0.75]);
                y = intersection(y, [0.25, 0.75]);
                break;
            case "full":
                x = intersection(x, [0, 1]);
                y = intersection(y, [0, 1]);
                break;
            default:
                break;
        }
    }

    return { x, y };
}

function distance2([x1, y1]: Range, [x2, y2]: Range) {
    return (x2 - x1) ** 2 + (y2 - y1) ** 2;
}

function usePloy(number = 16) {
    function getPoints(): Range[] {
        const limits = distributionToLimits(distribution.value);
        const rng = seedrandom(`${seed.value}-${currentSlideRoute.value.no}`);
        function randomBetween([a, b]: Range) {
            return rng() * (b - a) + a;
        }
        function applyOverflow(random: number, overflow: number) {
            random = random * (1 + overflow * 2) - overflow;
            return rng() < disturbChance ? random + (rng() - 0.5) * disturb : random;
        }
        return Array.from({ length: number })
            .fill(0)
            .map(() => [
                applyOverflow(randomBetween(limits.x), overflow),
                applyOverflow(randomBetween(limits.y), overflow),
            ]);
    }

    const points = ref(getPoints());
    const poly = computed(() => points.value.map(([x, y]) => `${x * 100}% ${y * 100}%`).join(", "));

    function jumpPoints() {
        const newPoints = new Set(getPoints());
        points.value = points.value.map((o) => {
            let minDistance = Number.POSITIVE_INFINITY;
            let closest: Range | undefined;
            for (const n of newPoints) {
                const d = distance2(o, n);
                if (d < minDistance) {
                    minDistance = d;
                    closest = n;
                }
            }
            newPoints.delete(closest);
            return closest;
        });
    }

    watch(currentSlideRoute, () => {
        jumpPoints();
    });

    return poly;
}

const poly1 = usePloy(10);
const poly2 = usePloy(6);
const poly3 = usePloy(3);
</script>

<template>
    <div v-if="$slidev.nav.currentLayout !== 'intro-image'">
        <div
            class="bg transform-gpu overflow-hidden pointer-events-none"
            :style="{ filter: `blur(70px) hue-rotate(${hue}deg)` }"
            aria-hidden="true"
        >
            <div
                class="clip bg-gradient-to-r from-[#cccccc] to-white/10"
                :style="{ 'clip-path': `polygon(${poly1})`, opacity: opacity }"
            />
            <div
                class="clip bg-gradient-to-l from-[#fefefe] to-white/10"
                :style="{ 'clip-path': `polygon(${poly2})`, opacity: opacity }"
            />
            <div
                class="clip bg-gradient-to-t from-[#ffffff] to-white/10"
                :style="{ 'clip-path': `polygon(${poly3})`, opacity: 0.2 }"
            />
        </div>

        <footer
            class="text-shadow-sm text-shadow-color-#000000 text-color-#ffffff op-25 absolute bottom-0 left-0 right-0 p-2 z-10 text-2"
        >
            Özyeğin University
            <span
                color-white
                op-40
                >•</span
            >
            COD 412 Sound Projects & Media
            <span
                color-white
                op-40
                >•</span
            >
            Alp Tuğan, PhD

            <div
                v-if="$slidev.nav.currentLayout !== 'cover'"
                class="absolute bottom-1 w-8 text-2 right-1 p-1 z-99999999 bg-#000000aa rounded-md"
            >
                {{ $slidev.nav.currentPage }} / {{ $slidev.nav.total }}
            </div>
        </footer>
    </div>
</template>

<style scoped>
.bg,
.clip {
    transition: all 2.5s ease;
}

.bg {
    position: absolute;
    inset: 0;
    z-index: -10;
}

.clip {
    clip-path: circle(75%);
    aspect-ratio: 16 / 9;
    position: absolute;
    inset: 0;
}

.light .clip {
    opacity: 1 !important;
}
</style>
